﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlbumPhoto.Models
{
    public class Comentariu
    {
        public string Text { get; set; }
        public string MadeBy { get; set; }
    }
}